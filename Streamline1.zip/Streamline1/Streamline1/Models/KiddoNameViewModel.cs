﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Streamline1.Models
{
    public class KiddoNameViewModel
    {
        public List<Kiddo> kiddos;
        public SelectList names;
        public string kiddoName { get; set; }
    }
}
